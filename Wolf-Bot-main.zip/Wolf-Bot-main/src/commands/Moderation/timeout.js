import { SlashCommandBuilder, PermissionFlagsBits, PermissionsBitField, ChannelType } from 'discord.js';
import { createEmbed, errorEmbed, successEmbed, infoEmbed, warningEmbed } from '../../utils/embeds.js';
import { logModerationAction } from '../../utils/moderation.js';
import { logger } from '../../utils/logger.js';
import { TitanBotError, ErrorTypes } from '../../utils/errorHandler.js';
import { t, pickLanguage } from '../../services/i18n.js';

import { InteractionHelper } from '../../utils/interactionHelper.js';
const durationChoices = [
    { name: "5 minutes", value: 5 },
    { name: "10 minutes", value: 10 },
    { name: "30 minutes", value: 30 },
    { name: "1 hour", value: 60 },
    { name: "6 hours", value: 360 },
    { name: "1 day", value: 1440 },
    { name: "1 week", value: 10080 },
];
export default {
    data: new SlashCommandBuilder()
        .setName("timeout")
        .setDescription("Timeout a user for a specific duration.")
        .addUserOption((option) =>
            option
                .setName("target")
                .setDescription("User to timeout")
                .setRequired(true),
        )
        .addIntegerOption(
            (option) =>
                option
                    .setName("duration")
                    .setDescription("Duration of the timeout")
                    .setRequired(true)
.addChoices(...durationChoices),
        )
        .addStringOption((option) =>
            option.setName("reason").setDescription("Reason for the timeout"),
        )
.setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    category: "moderation",

    async execute(interaction, config, client) {
        const lang = pickLanguage(config, interaction.guild);
        const deferSuccess = await InteractionHelper.safeDefer(interaction);
        if (!deferSuccess) {
            logger.warn(`Timeout interaction defer failed`, {
                userId: interaction.user.id,
                guildId: interaction.guildId,
                commandName: 'timeout'
            });
            return;
        }

        try {
            if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
                throw new TitanBotError("User lacks permission", ErrorTypes.PERMISSION, t(lang, 'wolf.cmd.mod.timeout.permDenied'));
            }

            const targetUser = interaction.options.getUser("target");
            const member = interaction.options.getMember("target");
            const durationMinutes = interaction.options.getInteger("duration");
            const reason = interaction.options.getString("reason") || t(lang, 'wolf.cmd.mod.common.noReason');

            if (targetUser.id === interaction.user.id) {
                throw new TitanBotError("Cannot timeout self", ErrorTypes.VALIDATION, t(lang, 'wolf.cmd.mod.common.cantSelf'));
            }
            if (targetUser.id === client.user.id) {
                throw new TitanBotError("Cannot timeout bot", ErrorTypes.VALIDATION, t(lang, 'wolf.cmd.mod.common.cantBot'));
            }
            if (!member) {
                throw new TitanBotError("Target not found", ErrorTypes.USER_INPUT, t(lang, 'wolf.cmd.mod.common.targetNotFound'));
            }
            if (!member.moderatable) {
                throw new TitanBotError("Cannot timeout member", ErrorTypes.PERMISSION, t(lang, 'wolf.cmd.mod.timeout.cannotTimeout'));
            }

            const durationMs = durationMinutes * 60 * 1000;
            await member.timeout(durationMs, reason);

            const durationDisplay =
                durationChoices.find((c) => c.value === durationMinutes)
                    ?.name || `${durationMinutes} minutes`;

            const caseId = await logModerationAction({
                client,
                guild: interaction.guild,
                event: {
                    action: "Member Timed Out",
                    target: `${targetUser.tag} (${targetUser.id})`,
                    executor: `${interaction.user.tag} (${interaction.user.id})`,
                    reason: `${reason}\nDuration: ${durationDisplay}`,
                    duration: durationDisplay,
                    metadata: {
                        userId: targetUser.id,
                        moderatorId: interaction.user.id,
                        durationMinutes,
                        timeoutEnds: new Date(Date.now() + durationMs).toISOString()
                    }
                }
            });

            await InteractionHelper.safeEditReply(interaction, {
                embeds: [
                    successEmbed(
                        t(lang, 'wolf.cmd.mod.timeout.successTitle', { user: targetUser.tag, duration: durationDisplay }),
                        `${t(lang, 'wolf.cmd.mod.common.reasonLabel')} ${reason}\n${t(lang, 'wolf.cmd.mod.common.caseLabel')}${caseId}`,
                    ),
                ],
            });
        } catch (error) {
            logger.error('Timeout command error:', error);
            await InteractionHelper.safeEditReply(interaction, {
                embeds: [
                    errorEmbed(error.userMessage || t(lang, 'wolf.cmd.mod.common.unexpectedError')),
                ],
            });
        }
    }
};



